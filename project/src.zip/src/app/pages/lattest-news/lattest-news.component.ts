import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lattest-news',
  templateUrl: './lattest-news.component.html',
  styleUrls: ['./lattest-news.component.css']
})
export class LattestNewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
