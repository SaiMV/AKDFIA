import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-governament-orders',
  templateUrl: './governament-orders.component.html',
  styleUrls: ['./governament-orders.component.css']
})
export class GovernamentOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
