import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'footer-page',
  templateUrl: './footer-page.component.html',
  styleUrls: ['./footer-page.component.css']
})
export class FooterPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
