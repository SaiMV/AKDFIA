import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-main-content',
  templateUrl: './home-page-main-content.component.html',
  styleUrls: ['./home-page-main-content.component.css']
})
export class HomePageMainContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
